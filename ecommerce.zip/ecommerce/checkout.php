<?php include('header.php');
if(!isset($_SESSION['user']))
{
	header('location:login.php');
}




?>

	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="index.php">Home</a></li>
				  <li class="active">Check out</li>
				</ol>
			</div><!--/breadcrums-->
<?php 
		$user=$_SESSION['user'];
	$catdata=$conn->query("SELECT * from user where user_name='$user'");
                        foreach($catdata as $row1) {
			                       
?>

			<div class="shopper-informations">
				<div class="row">
					
					<div class="col-sm-8 ">
						<div class="bill-to">
							<p>Bill To</p>
							<div class="form-one" style="width:100% !important;">
								<form>
							
									<input type="text" name="orderemail" placeholder="Email*" value="<?php echo $row1['user_email'];?>">
								
									<input type="text" name="ordername" placeholder="First Name *" value="<?php echo $row1['user_name'];?>" >
								
									<input type="text" name="orderaddress" placeholder="Address 1 *"  required>
						
							
									<input type="text" name="orderzip"  placeholder="Zip / Postal Code *" required>
									
								
									<input type="text" name="orderphone" placeholder="Phone *">
									<input type="text" placeholder="Mobile Phone" value="<?php echo $row1['MobileNumber'];?>">
									<input type="text" placeholder="Fax">
								</form>
							</div>
						</div>
					</div>
						<?php } 	?>
					<div class="col-sm-4">
								
					</div>					
				</div>
			</div>
			<div class="review-payment">
				<h2>Review & Payment</h2>
			</div>

			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Size</td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
						
						</tr>
					</thead>
					<tbody>  <?php    
                        				  
							$total=0;	   
						include('db.php');  
                        foreach($_SESSION['cartfiles'] as $id=>$value) {						
								  
                            //$cartdata = $conn->query("SELECT * from product where id='$id'");
			                     
                                     //$productimage = $cartdata['ProductImage'];
									 //$productname  = $cartdata['ProductName'];
			                         //$productprice = $cartdata['ProductPrice']; 
									 
		               $stmt = $conn->prepare("SELECT * from product where id='$id'"); 
                       $stmt->execute(); 
                       $row = $stmt->fetch();							 
									 
								    $productimage = $row['ProductImage'];
									$productname  = $row['ProductName'];
			                        $productprice = $row['ProductPrice'];	
                                    

                                     									
									 
									 
									 
									 
									 
									 
									 
                                  ?>
						<tr>
							 <td class="cart_product">
								<a href=""><img src="admin/images/<?php echo $productimage; ?>"  height="110" width="110"alt=""></a>
							</td>
							<td class="cart_description">
								<h4 style="margin-left: 60px;"><a href=""><?php echo $productname ;?></a></h4>
								
							</td>
							<td class="cart_price">
								<input class="cart_quantity_input" type="text" name="size" value="<?php echo $value[1]; ?>" autocomplete="off" size="2" disabled>
							</td>
							<td class="cart_price">
								<p><i class="fa fa-inr" aria-hidden="true"></i>   <?php echo $productprice ;?></p>
							</td>
							
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									
									<input class="cart_quantity_input" type="text" name="quantity" value="<?php echo $value[0]; ?>" autocomplete="off" size="2" disabled>
									
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price"><i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $grandtotal = $productprice* $value[0] ;?></p>
							</td>
							
						</tr>
					<?php 	$total=$total+$grandtotal;?>
						<?php  }  ?>

						
						
					</tbody>
				</table>
				<div class="col-sm-8"></div>
		<div class="col-sm-4">
		<a class="btn btn-default check_out" href="payment.php">Proceed To Pay</a>
		<br><br><br><br>
		</div>	
			</div>
			
		</div>
	
	</section> <!--/#cart_items-->

	
<?php include('footer1.php');?>
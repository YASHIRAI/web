<?php 
	include('header.php');

	$user=$_SESSION['user'];
	$catdata=$conn->query("SELECT * from user where user_name='$user'");
                        foreach($catdata as $row1) {
			                       	
?>
<body>
		<script type="text/javascript" src="js/script.js"></script>

<div class="col-sm-2">
</div>
<div class="col-sm-8">
<div class = "panel panel-default">
   <div class = "panel-heading"><h1>
     UPDATE PROFILE</h1>
   </div>
   
   <div class = "panel-body">
   <div class="col-sm-3">
   <h4>
    USER NAME <br><br><br>
	E-Mail<br><br><br>
	GENDER<br><br><br>
	DATE OF BIRTH<br><br><br>
	BIO<br><br><br>
	MOBILE NUMBER<br><br><br>
	PROFILE PHOTO<BR><BR><BR>
	
	</div>
   
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
	<div class="col-sm-6">
	<div class="form-group">
		
		<div class="col-sm-12">
		<input type="text" id="form-field-1"  autocomplete="off" name="user_name"  class="col-xs-10 col-sm-10" value="<?php echo ucfirst($row1['user_name']) ;  ?>" /><br><br><br>
		</div>
	</div>	
	<div class="form-group">
		
		<div class="col-sm-12">
		<input type="text" id="form-field-1"  autocomplete="off" name="user_email" class="col-xs-10 col-sm-10" value="<?php echo $row1['user_email'] ;  ?>" /><br><br><br>
		</div>
	</div>	
	<div class="form-group">
		<div class="col-sm-12">
			<input type="radio" name="gender" value="0" >Male
			<input type="radio" name="gender" value="1" >Female
			<input type="radio" name="gender" value="2" >Others<br><br><br>
	</div>		</div>
	
	<div class="form-group">
		
		<div class="col-sm-12">
		<input type="date" id="form-field-1"  autocomplete="off" name="date"class="col-xs-10 col-sm-10" value="<?php echo $row1['DateOfBirth'] ;  ?>" /><br><br><br>
		</div>
	</div>	
	<div class="form-group">
		
		<div class="col-sm-12">
		<input type="text" id="form-field-1"  autocomplete="off" name="bio"class="col-xs-10 col-sm-10" value="<?php if (empty($row1['Bio'])) { echo "--<br><br><br>"; }  else {echo $row1['Bio'];  }?>" /><br><br><br>
		</div>
	</div>
	<div class="form-group">
		
		<div class="col-sm-12">
		<input type="text" id="form-field-1"  autocomplete="off" name="phone"class="col-xs-10 col-sm-10" value="<?php echo $row1['MobileNumber'] ;  ?>" /><br><br><br>
		</div>
	</div>
	<div class="form-group">
		
		<div class="col-sm-12">
			<input type="file" id="form-field-1"  name="image" onchange="readURL(this);" class="col-xs-10 col-sm-10"  />
			</div>
	</div>
	
	
	

						<?php } ?>
						 </div>
						  <div class="col-sm-3" style="height:200px;width:200px;">
						 <img id="image" src="#"  />
						 </div>
						 
<div class="col-sm-12">

	 <input type="submit" class="btn btn-info" name="submit" value="SUBMIT"></input>
	 </FORM>
	 </div>
	 <div class="col-sm-12"></div>
	 <?php   
	     include('db.php');
								   if(isset($_POST['submit']))
								   {
									   $user_name         = $_POST['user_name'];
									   $user_email        = $_POST['user_email'];
									   $gender            = $_POST['gender'];
									   $date              = $_POST['date'];
									   $bio               = $_POST['bio'];
									   $image             = $_FILES['image']['name'];
									   $phone             = $_POST['phone'];
									   $temp_name         =$_FILES["image"]["tmp_name"];
							
									   
		$editdetails = "UPDATE user SET user_name='$user_name',user_email='$user_email', Gender='$gender', DateOfBirth='$date', Bio='$bio', ProfilePhoto='$image', MobileNumber='$phone' where user_id= '$row1[user_id]'; ";
	//echo  $insertproduct; die;
	
	   $conn->exec($editdetails);								   
									   
	try {	
      $target_path = "users/".$image;
	  move_uploaded_file($temp_name, $target_path);
     
    echo "Details Edited successfully";
	header('Location:profile.php');
    }
catch(PDOException $e)
    {
    echo $editdetails . "<br>" . $e->getMessage();
    }
								   }
								   
	 
	 ?>
	
	    <script>
								        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image')
                        .attr('src', e.target.result)
                        .width(220)
                        .height(300);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
								   
								   
								   
								   </script>
	
   </div>
   
   
</div>
						
</div>

<div class="col-sm-2">
</div>

</body>
<div class="col-sm-12">
<?php include('footer1.php');?>
</div>
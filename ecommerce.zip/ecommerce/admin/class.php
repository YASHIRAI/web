<?php 
include('db.php');

function get_category_id($id)
{     
//echo $id;
     global $conn;

	 foreach($conn->query("select * from category where id ='$id'") as $row2) {
			echo 	$row2['CategoryName'];			
	 }

	
	
}






?>
<?php

	include('header.php'); 
	include('sidebar.php');
	include('featureitems.php');
 ?>
	
	
	
	<section>
	<h2 class="title text-center">All Products</h2>
		<?php       
								   
						include('db.php');  
						
                        foreach($conn->query("SELECT * from product where Featured='0'") as $row1) {
			                       $id = $row1['id'];
                                  
                                  ?>
						
						<div class="col-sm-4">
							
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="product-details.php?single=<?php echo $id ;?>"><img src="admin/images/<?php echo $row1['ProductImage']; ?>"  alt="" class="img-responsive"/></a>
										<h2><i class="fa fa-inr" aria-hidden="true"></i> <?php echo $row1['ProductPrice'];?></h2>
										<p><?php echo $row1['ProductName'];?></p>
										<form action="addcart.php" method="post">
											<input type="hidden" name="id" value="<?php echo $row1['id'];?>">
											<div class="col-sm-3">
											<input type="number" name="qty" placeholder="qty" min="1" style="width:170% !important;">
										
										</div>
										<div class="col-sm-3">
											<select name="size" value="size" style="width:170% !important;">
											   <option value="0" class="active">size</option>
											   <option value="1" >XS</option>	
											   <option value="1" >S</option>
											  	<option value="1" >M</option>
												<option value="1" >L</option>
												<option value="1" >XL</option>
												</select>
												
												</div>
												<div class="col-sm-6">
												</div>
<input type="submit" name="submit" value="Add to Cart" class="btn btn-default add-to-cart"></input>									</div>
									</form>
								</div>
								<div class="choose">
									
								</div>
							</div>
						</div>
							<?php } ?>
						
					</div><!--features_items-->
				</div>
			</div>
			
		</div>
	</section>
	
	<?php include('footer1.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Checkout | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>


	<section id="cart_items">
		<div class="container" style="padding-top:200px;">
			

			
			

			<!--div class="register-req">
				<p>Please use Register And Checkout to easily get access to your order history, or use Checkout as Guest</p>
			</div--><!--/register-req-->

			<div class="shopper-informations">
			
				<div class="row">
				<div class="col-sm-4">
				</div>
					<div class="col-sm-4">
						<div class="shopper-info">
							<p>Card Information</p>
							<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
								<input type="text" placeholder="Card Number"  required>
								<input type="number" placeholder="mm" min="1" max="12" required>
								<input type="number" placeholder="yyyy" min="2018" max="2048" required>
								<input type="number" placeholder="CVC" min="100" max="999" required>
								<input type="submit" name="submit" class="btn btn-primary" value="Confirm">
							</form>
							<?php 
								if(isset($_POST['submit']))
								{
									header('Location:invoice.php');
								}
							
							
							?>
							
						</div>
					</div>
				<div class="col-sm-4">
				</div>
										
				</div>
			</div>
			

			
		
		</div>
	</section> <!--/#cart_items-->

	


	


    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
						<?php 
						include('db.php');  
                        foreach($conn->query('SELECT * FROM category where AdminID=0') as $row) {
						
						?>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#<?php echo $row['id']; ?>">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											<?php echo $row['CategoryName']; ?>
										</a>
									</h4>
								</div>
								<div id="<?php echo $row['id']; ?>" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
										<?php foreach($conn->query("SELECT * FROM category where AdminID='".$row['id']."'") as $row1) {
											?>
											<li><a href="singlecategory.php?category=<?php echo $row1['id']; ?>">	<?php echo $row1['CategoryName']; ?> </a></li>
										<?php } ?>
										</ul>
									</div>
								</div>
							</div>
						
							<?php } ?>
							
							<!--div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Kids</a></h4>
								</div>
							</div-->
							
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Brands</h2>
							<div class="brands-name">
							<FORM action="brands.php" method="POST">
							<?php 
						include('db.php');
                        foreach($conn->query('SELECT count(id) AS idd, ProductBrand FROM product GROUP BY ProductBrand ') as $row2) {
						//print_r($row2); die;
						?>
							
								<ul class="nav nav-pills nav-stacked">
								
									<li><span class="pull-right">
									<input type="checkbox" name="brand[]" value="<?php echo "'".$row2['ProductBrand']."'"; ?>">(<?php echo $row2['idd']; ?>)</input></span><?php echo $row2['ProductBrand']; ?></li>
									
								</ul>
							
							<?php } ?>
							<input type="submit" name="submit" value="DONE"></input>
							</form>
							</div>
						</div><!--/brands_products-->
		
						
						<div class="shipping text-center"><!--shipping-->
							<img src="images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				
				
<?php
session_start();
include('db.php');
//$paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
//$paypalID = 'Insert_PayPal_Email';
$total=0;
$total_qty=0;
 foreach($_SESSION['cartfiles'] as $id=>$value) {						
								  
                            //$cartdata = $conn->query("SELECT * from product where id='$id'");
			                     
                                     //$productimage = $cartdata['ProductImage'];
									 //$productname  = $cartdata['ProductName'];
			                         //$productprice = $cartdata['ProductPrice']; 
									 
		               $stmt = $conn->prepare("SELECT * from product where id='$id'"); 
                       $stmt->execute(); 
                       $row = $stmt->fetch();							 
									 
								    $productimage = $row['ProductImage'];
									$productname  = $row['ProductName'];
			                        $productprice = $row['ProductPrice'];
									
									$total=$total+$productprice;
									
									$total_qty=$total_qty+$value[0];
									
									
 }
?>

<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
	<input type='hidden' name='business' value='BN3ABQD5EF5F486'>
	<input type='hidden' name='item_name' value='Camera'>
	<input type='hidden' name='item_number' value='CAMN1'>
	<input type='hidden' name='amount' value='<?=$total?>'>
	<input type='hidden' name='no_shipping' value='1'>
	<input type='hidden' name='currency_code' value='USD'>
	<input type='hidden' name='notify_url' value='http://localhost/ecommerce/success.php'>
	<input type='hidden' name='cancel_return' value='http://localhost/ecommerce/cancel.php'>
	<input type='hidden' name='return' value='http://localhost/ecommerce/success.php'>
	<!-- COPY and PASTE Your Button Code -->
	<input type="hidden" name="cmd" value="_s-xclick">
	<input type="hidden" name="hosted_button_id" value="### COPY FROM BUTTON CODE ###">
	<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_buynow_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
</form>
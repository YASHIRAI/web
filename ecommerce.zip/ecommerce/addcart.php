<?php 
  session_start();
  include('db.php');
  if(isset($_POST['submit']))
  {
	   $id = $_POST['id'];
	   $qty = $_POST['qty'];
	   $size = $_POST['size'];
	   if(!empty($qty)){
	   $_SESSION['cartfiles'][$id]=array($qty, $size);
	   }
	   else 
	   {
		    $_SESSION['cartfiles'][$id]=array(1, $size);
	   }
	   header("Location:cart.php");
  }
?>
<?php

	include('header.php'); 
	include('sidebar.php');
	//include('featureitems.php');
 ?>
	<div class="col-sm-9">
	
	<section>
<h2 class="title text-center">SEARCH RESULTS</h2>
<?php 
include('db.php');
if(isset($_GET['submit']))
{
	$search = $_GET['search'];

	//echo "SELECT * FROM product WHERE ProductBrand LIKE '%$search%' ORDER BY id"; die;
	 $searchproduct= $conn->query("SELECT * FROM product WHERE ProductBrand LIKE '%$search%' or ProductName LIKE '%$search%' OR ProductDescription LIKE '%$search%' ORDER BY id");
	//die();
}

foreach($searchproduct as $row1) {
	$id = $row1['id'];
?>	
	
						
						<div class="col-sm-4">
							
							<div class="product-image-wrapper">
								<div class="single-products">
									<div class="productinfo text-center">
										<a href="product-details.php?single=<?php echo $id ;?>"><img src="admin/images/<?php echo $row1['ProductImage']; ?>"  alt="" class="img-responsive"  alt="" class="img-responsive"/></a>
										<h2><i class="fa fa-inr" aria-hidden="true"></i><?php echo $row1['ProductPrice'];?></h2>
										<p><?php echo $row1['ProductName'];?></p>
										<form action="addcart.php" method="post">
											<input type="hidden" name="id" value="<?php echo $row1['id'];?>">
											<div class="col-sm-3">
											<input type="number" name="qty" placeholder="qty" min="1" style="width:170% !important;">
										
										</div>
										<div class="col-sm-3">
											<select name="size" value="size" style="width:170% !important;">
											   <option value="0" class="active">size</option>
											   <option value="1" >XS</option>	
											   <option value="1" >S</option>
											  	<option value="1" >M</option>
												<option value="1" >L</option>
												<option value="1" >XL</option>
												</select>
												
												</div>
												<div class="col-sm-6">
												</div>
												<input type="submit" name="submit" value="Add to Cart" class="btn btn-default add-to-cart"></input>									</div>
									</form>
									
									
								</div>
								<div class="choose">
									<!--ul class="nav nav-pills nav-justified">
										<li><a href=""><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href=""><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul-->
								</div>
							</div>
						</div>
						
<?php } ?>					
					</div><!--features_items-->
				</div>
			</div>
			
		</div>
		<BR><BR><BR>
		
	</section>
	
	<?php include('footer1.php');?>
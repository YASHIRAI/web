<?php include('header.php');

	$user=$_SESSION['user'];
	$catdata=$conn->query("SELECT * from user where user_name='$user'");
                        foreach($catdata as $row1) {
			                       
	
?>
	
<body>

<div class="col-sm-2">
</div>
<div class="col-sm-8">
<div class = "panel panel-default">
   <div class = "panel-heading"><h1>
     USER PROFILE</h1>
   </div>
   
   <div class = "panel-body">
   <div class="col-sm-3">
   <h4>
    NAME <br><br><br>
	E-Mail<br><br><br>
	GENDER<br><br><br>
	DATE OF BIRTH<br><br><br>
	BIO<br><br><br>
	MOBILE NUMBER<br><br><br>
	
	
	</div>
	 <div class="col-sm-4">
	<?php echo " <h4>".ucfirst($row1['user_name'])."</h4>" ;  ?><br>
	<?php echo " <h4>".$row1['user_email']."</h4>" ;  ?><br>
	<?php if ($row1['Gender']==0) { echo "<h4>Male</h4>"; }  else {if ($row1['Gender']==1) { echo "<h4>Female</h4>"; }  else echo "<h4>Others</h4>" ; }?><br>
    <?php if (empty($row1['DateOfBirth'])) { echo "<h4>--</h4>"."<br>"; }  else {echo " <h4>".$row1['DateOfBirth']."</h4>" ;  }?><br>
	<?php if (empty($row1['Bio'])) { echo "<h4>--</h4>"."";?><br> <?php }  else {echo " <h4>".$row1['Bio']."</h4>" ;  }?>
	
	<?php if (empty($row1['MobileNumber'])) { echo "<<h4>--</h4>"; ?><br><?php  } else {echo " <h4>".$row1['MobileNumber']."</h4>" ;  }?><br>
	
    </h4>
	<form action="update.php" method="POST">
	 <input type="submit" class="btn btn-success" name="edit" value="EDIT"></input>
	 </FORM>
   </div>
   
   <div class="col-sm-4">

   <img src="users/<?php echo $row1['ProfilePhoto']; ?>"  alt="" class="img-responsive"></image>
   </div>
</div>
						<?php }?>
</div>
</div>
<div class="col-sm-2">
</div>

</body>
<div class="col-sm-12">
<?php include('footer1.php');?>
</div>
	<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">recommended items</h2>
						
						<?php       
								   
						include('db.php');  
                                foreach($conn->query("SELECT * from product where RecommendedItems='1' and ProductCategory in(4,5,6,7,8)") as $row1) {
			                     $id = $row1['id'];

                                  ?>
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							
							<div class="carousel-inner">
								<div class="item active">	
								
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<a href="product-details.php?single=<?php echo $id ;?>"><img src="admin/images/<?php echo $row1['ProductImage']; ?>" CLASS="img-responsive" alt="" /></a>
													<h2>Rs <?php echo $row1['ProductPrice'];?></h2>
													<p><?php echo $row1['ProductName'];?></p>
											<a href="cart.php?pid=<?php echo $row1['id']; ?>&qty=1" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
								
							
								</div>
								<div class="item">	
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/home/recommend1.jpg" alt="" />
													<h2>$56</h2>
													<p>Easy Polo Black Edition</p>
													<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
												</div>
												
											</div>
										</div>
									</div>
									
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>	
							  
						</div>
	<?php } ?>
						</div>
					

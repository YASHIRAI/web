<?php 
session_start();

$deleteid = $_GET['deleteid'];
//echo $deleteid;
unset($_SESSION['cartfiles'][$deleteid]);
header('location:cart.php');





?>
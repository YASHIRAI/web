-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 06, 2018 at 10:09 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtest`
--
CREATE DATABASE IF NOT EXISTS `dbtest` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbtest`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

DROP TABLE IF EXISTS `tbl_products`;
CREATE TABLE IF NOT EXISTS `tbl_products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(35) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`product_id`, `product_name`) VALUES
(4, 'Moto Xplay');
--
-- Database: `hackathon_sample`
--
CREATE DATABASE IF NOT EXISTS `hackathon_sample` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hackathon_sample`;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
CREATE TABLE IF NOT EXISTS `user_details` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `aadhaar_number` bigint(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile_number` bigint(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `aadhar` (`aadhaar_number`),
  UNIQUE KEY `aadhaar_number` (`aadhaar_number`),
  UNIQUE KEY `aadhaar_number_2` (`aadhaar_number`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `aadhaar_number`, `password`, `name`, `email`, `mobile_number`, `date_of_birth`, `address`) VALUES
(2, 123456789012, 'abs1234', 'yashi rai', 'yashirai@hotmail.com', 9876543210, '2017-11-30', 'rajkot'),
(3, 346310484532, 'gfhgf', ' YASHI RAI ', 'yashi_rai@hotmail.com', 8786767657, '1999-01-26', 'Rajkot'),
(4, 456789321098, 'AAryan@282', 'Nishant Kumar Singh', 'nishantaaryan@gmail.com', 7890765356, '2017-12-28', 'Rajkot'),
(5, 876534560987, 'Nisha@666', 'Nisha', 'nsa@gmail.com', 8978675645, '1973-07-05', 'Rajkot'),
(6, 987654329876, 'dummy', 'Dummy', 'dummy@abc.com', 9999988888, '1999-12-18', 'Rajkot');
--
-- Database: `listing_members`
--
CREATE DATABASE IF NOT EXISTS `listing_members` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `listing_members`;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `full_name`, `email`, `age`) VALUES
(3, 'Rachid Kabbour', 'rachid@domain.com', 25);
--
-- Database: `project`
--
CREATE DATABASE IF NOT EXISTS `project` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AdminId` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `AdminId`, `Password`) VALUES
(1, 'admin', 'admin1234');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(250) NOT NULL,
  `AdminID` int(11) NOT NULL,
  `CreatedOn` timestamp NOT NULL,
  `Status` enum('0','1') NOT NULL COMMENT '0=>DeActivate, 1=>Activate',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `CategoryName`, `AdminID`, `CreatedOn`, `Status`) VALUES
(1, 'MEN', 0, '2018-01-03 04:59:37', '1'),
(2, 'WOMEN', 0, '2018-01-03 04:59:42', '1'),
(3, 'KIDS', 0, '2018-01-03 04:59:47', '1'),
(4, 'T-SHRTS', 1, '2018-01-03 05:42:14', '1'),
(5, 'FORMAL SHIRT', 1, '2018-01-03 05:42:26', '1'),
(6, 'CASUAL SHIRT', 1, '2018-01-03 05:42:34', '1'),
(7, 'JEANS', 1, '2018-01-03 05:42:42', '1'),
(8, 'TOPS ', 2, '2018-01-03 05:42:58', '1'),
(9, 'DRESSES', 2, '2018-01-03 05:43:04', '1'),
(10, 'BOYS', 3, '2018-01-03 05:44:08', '1'),
(11, 'GIRLS', 3, '2018-01-03 05:44:13', '1');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(50) NOT NULL,
  `ProductPrice` int(11) NOT NULL,
  `ProductQuantity` int(11) NOT NULL,
  `ProductBrand` varchar(200) NOT NULL,
  `ProductImage` varchar(255) NOT NULL,
  `ProductDescription` text NOT NULL,
  `ProductSize` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL COMMENT '0=>DeActivate, 1=>Activate',
  `ProductCategory` varchar(255) NOT NULL,
  `CreateDate` timestamp NOT NULL,
  `Featured` enum('0','1') NOT NULL COMMENT '0=>Not featured,1=>Featured',
  `RecommendedItems` enum('0','1') NOT NULL COMMENT '0=>Not Recommended,1=>Recommended',
  `SpecialOffer` enum('0','1') DEFAULT '0' COMMENT '0=>Not Offer,1=>offer',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `ProductName`, `ProductPrice`, `ProductQuantity`, `ProductBrand`, `ProductImage`, `ProductDescription`, `ProductSize`, `Status`, `ProductCategory`, `CreateDate`, `Featured`, `RecommendedItems`, `SpecialOffer`) VALUES
(1, 'FORMAL SHIRT', 699, 67, 'HANCOCK', '11460624898615-Hancock-Men-Shirts-8481460624898035-1.jpg', 'NAVY BLUE ALTER SHIRT', 'XS,S,M,L,XL', '1', '5', '2018-01-03 05:50:18', '1', '0', '0'),
(2, 'TROUSERS CASUAL', 1299, 50, 'U.S POLO ASSN', '11467112521651-US-Polo-Assn-Beige-Corduroy-Slim-Fit-Casual-Trousers-9961467112521488-1.jpg', 'GREY METAL CHINOS', '', '1', '7', '2018-01-03 05:51:36', '0', '0', '0'),
(3, 'RIGO', 399, 40, 'RIGO', '11471867758344-Rigo-Navy--White-Striped-Smart-Fit-T-shirt-1901471867757920-1.jpg', 'NAVY BLUE STRIPED SHIRT', 'XS,S,M,L,XL', '1', '4', '2018-01-03 05:54:39', '0', '0', '0'),
(4, 'CHINOS OLIVE', 899, 45, 'U.S POLO ASSN', '11473323373626-US-Polo-Assn-Men-Olive-Green-Slim-Fit-Trousers-8931473323373252-1.jpg', 'OLIVE GREY CHINOS', 'XS,S,M,L,XL', '1', '7', '2018-01-03 05:58:02', '0', '0', '0'),
(5, 'NAVY BLUE T-SHIRT', 499, 34, 'WROGN', '11486098096705-WROGN-Men-Navy-Blue-Solid-Polo-Collar-T-Shirt-8851486098096368-1.jpg', 'NAVY BLUE POLO SHIRT', 'XS,S,M,L,XL', '1', '4', '2018-01-03 06:02:51', '0', '0', '0'),
(6, 'T-SHIRT WROGN', 349, 43, 'WROGN', '11486099736006-WROGN-Men-Orange-Striped-Polo-Collar-T-Shirt-8251486099735821-1.jpg', 'STRIPED HOLO T-SHIRT', 'XS,S,M', '1', '4', '2018-01-03 06:04:21', '1', '0', '0'),
(7, 'HANCOCK FORMAL', 799, 54, 'HANCOCK', '11486536910999-Hancock-Men-Shirts-7751486536910660-1.jpg', 'RED SLIM FIT SHIRT', 'XS,S,M,L,XL', '1', '5', '2018-01-03 06:05:05', '0', '0', '0'),
(8, 'GREY MELAD T-SHIRT', 560, 45, 'WROGN', '11488457530713-WROGN-Men-Grey-Melange-Solid-Polo-Collar-T-Shirt-6461488457530409-1.jpg', 'GREY', 'XS,S,M,L,XL', '1', '4', '2018-01-03 06:05:53', '0', '0', '0'),
(9, 'INVICTUS FORMAL SHIRT', 450, 43, 'INVICTUS', '11489410090880-INVICTUS-White-Printed-Slim-Fit-Formal-Shirt-6091489410090504-1.jpg', 'SFWER', 'XS,S,M,L,XL', '1', '5', '2018-01-03 06:06:35', '0', '0', '0'),
(10, 'ROADSTER CASUAL SHIRT', 560, 35, 'ROADSTER', '11507894808031-Roadster-Men-Green-Slim-Fit-Solid-Casual-Shirt-1321507894807722-1.jpg', 'SFDS', 'XS,S,M,L,XL', '1', '6', '2018-01-03 06:07:33', '0', '0', '1'),
(11, 'ROADSTER CHECKED', 548, 76, 'ROADSTER', '11503925666468-Roadster-Men-Black--Red-Checked-Casual-Shirt-6171503925666405-1.jpg', 'FDS', 'XS,S,M,L,XL', '1', '6', '2018-01-03 06:08:13', '0', '0', '0'),
(12, 'AMERICAN CREW JEANS', 910, 45, 'AMERICAN CREW', '11505132343749-American-Crew-Men-Blue-Straight-Fit-Mid-Rise-Mildly-Distressed-Stretchable-Jeans-1301505132343570-1.jpg', 'RSWF', 'XS,S,M,L,XL', '1', '7', '2018-01-03 06:11:47', '1', '0', '0'),
(13, 'WROGN MUSTARD BLUE STRIPED', 690, 45, 'WROGN', '11512017703224-WROGN-Blue--Mustard-Yellow-Striped-Polo-Slim-T-shirt-8271512017702859-1.jpg', 'WROGN T-SHIRT', 'XS,S,M,L,XL', '1', '4', '2018-01-03 06:12:55', '0', '0', '0'),
(14, 'SCOTCH AND SODA JEANS', 457, 45, 'SCOTCH AND SODA', '11509188915766-Scotch--Soda-Men-Blue-Skinny-Fit-Mid-Rise-Clean-Look-Jeans-7881509188915591-1.jpg', 'SKIN FIT JEANS', 'XS,S,M,L,XL', '1', '7', '2018-01-03 06:13:55', '0', '0', '0'),
(15, 'BROWN SCOTCH AND SODA ', 897, 87, 'SCOTCH AND SODA', '11509176548163-Scotch--Soda-Men-Brown-Skinny-Fit-Mid-Rise-Clean-Look-Jeans-7291509176547953-1.jpg', 'JEANS', 'XS,S,M,L,XL', '1', '7', '2018-01-03 06:14:41', '0', '0', '0'),
(16, 'EAVAN MAXI DRESS', 1299, 44, 'EAVAN', '11448517782275-Eavan-Green-Maxi-Dress-7211448517782052-1.jpg', 'GREEN FULL LENGTH MAXI DRESS', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:16:47', '1', '0', '0'),
(17, 'VAAK SHIRT DRESS', 899, 30, 'VAAK', '11449838629077-Vaak-Black-Tailored-Dress-2591449838628410-1.jpg', 'VAAK MID-LENGTH SHIRT DRESS BLACK', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:17:35', '0', '0', '0'),
(18, 'TOKYO TALKIES TUNICS', 990, 70, 'TOKYO TALKIES', '11465541343303-Tokyo-Talkies-Women-Tunics-8261465541343177-1.jpg', 'BLUE FULL LENGTH TUNIC ETHNIC INDIAN', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:19:46', '0', '0', '0'),
(19, 'REGULAR TOP MARIE CLAIRE', 899, 56, 'MARIE CLAIRE', '11472473187734-Marie-Claire-Women-Coral-Solid-Regular-Top-2431472473187670-1.jpg', 'PEACH COLOURED FULL LENGTH CAPE TOP', 'XS,S,M,L,XL', '1', '8', '2018-01-03 06:20:39', '0', '0', '0'),
(20, 'ZIMA LETO DRESS', 590, 43, 'ZIMA LETO', '11473315885947-Zima-Leto-Women-Dresses-891473315885662-1.jpg', 'BLACK AND WHITE STRIPED DRESS', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:21:26', '0', '0', '1'),
(21, 'ZIMA LETO WOMEN', 590, 65, 'ZIMA LETO', '11474871829495-Zima-Leto-Women-Dresses-2361474871829273-1.jpg', 'FORMAL DRESS PENCIL ', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:23:28', '0', '0', '0'),
(22, 'ZIMA LETO MUSTARD', 499, 980, 'ZIMA LETO', '11474880634667-Zima-Leto-Women-Mustard-Solid-A-line-Dress-6611474880634379-1.jpg', 'MUSTARD KNEE LENGTH DRESS', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:24:09', '0', '0', '0'),
(23, 'CATION FULL LENGTH TUNIC TOP', 560, 34, 'CATION', '11476426630940-Cation-Women-Tops-3231476426630457-1.jpg', 'FLORAL PRINT A-LINE FRONT SLIT TOP', 'XS,S,M,L,XL', '1', '8', '2018-01-03 06:25:29', '1', '0', '0'),
(24, 'MISS CHASE BELTED DRESS', 399, 456, 'MISS CHASE', 'Miss-Chase-Black-Belted-Dress_1_a8843b4826d5886b6996e94c826d80d4.jpg', 'BLACK MID-LENGTH DRESS WITH RED LEATHER BELT', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:28:38', '0', '0', '0'),
(25, 'EAVAN BEIGE DRESS', 1899, 54, 'EAVAN', 'Eavan-Beige--Black-Maxi-Dress_1_f1e20bfe7806d1804ad0f300b5097dfe.jpg', 'BLACK AND BEIGE DRESS FULL LENGTH GEORGETTE', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:29:35', '0', '0', '0'),
(26, 'CATION SHIRT', 399, 87, 'CATION', 'Cation-Women-Shirts_f4c3ee167741452d742c89f583b3cc39_images.jpg', 'CATION SKY BLUE SHIRT ', 'XS,S,M,L,XL', '1', '8', '2018-01-03 06:30:26', '0', '0', '0'),
(27, 'VAAK MAXI FLOW DRESS', 988, 34, 'VAAK', '11512552047080-na-6971512552046969-1.jpg', 'BLUE VAAK DRESS FLOWY', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:36:48', '0', '0', '0'),
(28, 'KOOK N KEECH ', 350, 509, 'KOOK N KEECH ', '11486638528866-Kook-N-Keech-Women-Black-Printed-Round-Neck-T-Shirt-3011486638528676-1.jpg', 'ALT T-SHIRT ', 'XS,S,M,L,XL', '1', '8', '2018-01-03 06:37:55', '1', '0', '0'),
(30, 'FABALLEY YELLOW DRESS', 580, 670, 'FABALLEY', '11488444005887-FabAlley-Women-Mustard-Solid-A-Line-Dress-2921488444005681-1.jpg', 'YELLOW COLD SHOULDER DRESS', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:40:37', '0', '0', '0'),
(31, 'WOMEN PINK DRESS', 899, 65, 'MARIE CLAIRE', 'La-Zoire-Women-Dresses_1_841b654f210a75ba9e8e2511304643a2.jpg', 'PINK DRESS', 'XS,S,M,L,XL', '1', '9', '2018-01-03 06:41:34', '0', '0', '0'),
(32, 'PEPPERMINT GIRLS FROCK', 500, 43, 'PEPPERMINT', '11475576242940-Peppermint-Girls-Peach-Coloured-Floral-Print-Fit--Flare-Dress-6601475576242854-1.jpg', 'BABY PINK AND BLUE PRINTED FROCK', 'XS,S,M,L,XL', '1', '11', '2018-01-04 13:17:18', '1', '0', '0'),
(33, 'PEPPERMINT BLUE FROCK', 799, 65, 'PEPPERMINT', '11484821088470-Peppermint-Girls-Dresses-9161484821088350-1.jpg', 'BABY BLUE FROCK WITH FRILLS ', 'XS,S,M', '1', '11', '2018-01-04 13:18:24', '0', '0', '0'),
(34, 'PANTALOONS KIDS JEANS', 799, 87, 'PANTALOONS', '11505827165391-Chirpie-Pie-by-Pantaloons-Boys-Jeans-4221505827165291-1.jpg', 'PANTALOONS CAPRI BOYS', 'XS,S,M,L,XL', '1', '10', '2018-01-06 09:50:57', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `create_date` timestamp NOT NULL,
  `Gender` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0=>Mail,1=>Female,2=>Others',
  `DateOfBirth` date DEFAULT NULL,
  `Bio` varchar(400) DEFAULT NULL,
  `MobileNumber` bigint(20) DEFAULT NULL,
  `ProfilePhoto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `create_date`, `Gender`, `DateOfBirth`, `Bio`, `MobileNumber`, `ProfilePhoto`) VALUES
(1, 'Asif', 'asif@gmail.com', 'asif1234', '2018-01-01 11:10:16', '0', '1992-02-06', '', 9876543210, ''),
(2, 'Yashi', 'yashi_rai@hotmail.com', 'abcxyz', '2018-01-01 11:31:01', '2', '1999-01-26', '', 9876543211, '11508739030076-Cayman-Girls-Beige-Self-Design-Woollen-Poncho-Sweater-1261508739030318-1.jpg'),
(3, 'Mayank', 'krmayank@gmail.com', 'itsmakx', '2018-01-01 11:35:23', '0', '1997-04-08', '    Anime lover', 9457708566, 'IMG_20171203_174753037_HDR.jpg');
--
-- Database: `session_data`
--
CREATE DATABASE IF NOT EXISTS `session_data` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `session_data`;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user` text NOT NULL,
  `Phone` bigint(100) NOT NULL,
  `plan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `user`, `Phone`, `plan`) VALUES
(11, 'yashi', 9876543210, 'big'),
(10, 'ashish', 123456, 'big'),
(9, '22', 232, 'highest'),
(8, '22', 232, 'highest'),
(12, 'yashi', 9876543210, 'huge'),
(13, 'pragati', 9458568684, 'huge');
--
-- Database: `site`
--
CREATE DATABASE IF NOT EXISTS `site` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `site`;

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

DROP TABLE IF EXISTS `product_list`;
CREATE TABLE IF NOT EXISTS `product_list` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_name` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `price_listed` int(40) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `customer_name`, `email`, `product_id`, `price_listed`, `quantity`) VALUES
(1, 'yashi rai', 'yashi_rai@hotmail.com', '51526', 349, 2),
(2, 'Nisha', 'nisharai272@gmail.com', '51526', 349, 3),
(13, 'Shivani', 'shivani@gmail.com', '51526', 349, 2),
(31, 'Anant', 'aky@sjmail.com', '54646', 399, 9),
(19, 'Amisha', 'amaya@gmail.com', '51526', 349, 5),
(20, 'ananya', 'anniroy@ymail.com', '52345', 1849, 1),
(21, 'Xyz', 'xyz@abc.com', '54646', 399, 1),
(41, 'tiasha', 'tia@haldar.com', '57878', 999, 3),
(42, 'hfh', 'abc@abv.com', '54646', 399, 3),
(43, 'hfh', 'abc@abv.com', '54646', 399, 3),
(29, 'Xyz', 'xyz@abc.com', '54646', 399, 1),
(30, 'aman', 'Am@hotmail.com', '59876', 199, 7);
--
-- Database: `user`
--
CREATE DATABASE IF NOT EXISTS `user` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `user`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `name`, `password`) VALUES
(1, 'Nisha', 'sdsad'),
(2, 'wscx', 'afcsxzc'),
(3, 'tiasha', 'tia123'),
(4, 'guddi', 'dsfd334');

-- --------------------------------------------------------

--
-- Table structure for table `studentmarks`
--

DROP TABLE IF EXISTS `studentmarks`;
CREATE TABLE IF NOT EXISTS `studentmarks` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `student_name` text NOT NULL,
  `roll_no` varchar(40) NOT NULL,
  `marks` int(100) NOT NULL,
  `status` varchar(40) NOT NULL DEFAULT 'PASS',
  `date_of_exam` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `I.D` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentmarks`
--

INSERT INTO `studentmarks` (`id`, `student_name`, `roll_no`, `marks`, `status`, `date_of_exam`) VALUES
(11, 'Shivankar', '163097', 56, 'Fail', '2017-12-05'),
(3, 'datashree', '163011', 45, 'Pass', '2017-12-06'),
(4, 'shweta', '163018', 100, 'Pass', '2017-12-13'),
(6, 'Yashi', '163013', 21, 'Fail', '2017-12-11'),
(9, 'abc', '163085', 56, 'Pass', '2017-12-06'),
(10, 'yashi rai', '163078', 98, 'Pass', '2017-12-20');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

DROP TABLE IF EXISTS `user_login`;
CREATE TABLE IF NOT EXISTS `user_login` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`id`, `user_name`, `password`) VALUES
(1, 'Yashi', 'manno'),
(2, 'xyz', 'sadd'),
(3, 'lucky', 'sdsds'),
(4, 'ashish', 'ashish');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include('header.php');
include('slider.php');
include('sidebar.php');
include('featureitems.php');

?>
<div class="col-sm-12">
<BR><BR><BR><BR><BR>
	</section>
	
<?php
include('footer1.php');
?>
	

					
				
	
	
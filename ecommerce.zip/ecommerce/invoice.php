<?php 
ob_start();
session_start(); 

include('db.php'); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>PRICE SUTRA</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
								<li><a href="#"><i class="fa fa-phone"></i> +91 98 76 54 321</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> info@pricesutra.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="logo.jpg" alt="" style="height:50px;width:130px;" /></a>
						</div>
						<div class="btn-group pull-right">
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									INDIA									
									
								</button>
								
							</div>
							
							<div class="btn-group">
								<button type="button" class="btn btn-default dropdown-toggle usa" data-toggle="dropdown">
									INDIAN RUPEE
									
								</button>
								
							</div>
						</div>
					</div>
					<div class="col-sm-8">
					
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						
					</div>
					
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->
	

	
		<?php 	$user=$_SESSION['user'];
	$catdata=$conn->query("SELECT * from user where user_name='$user'");
                        foreach($catdata as $row1) {
			                       
						
?>	
	
<div class="col-sm-6" style="padding-left:200px;">

   <div class = "panel-heading" style="padding-left:80px;"><h3 >
      INVOICE</h3>
   </div>
   
   <div class = "panel-body">
   <div class="col-sm-6">
   <h6>
    NAME: <br><br>
	E-Mail:<br><br>	
	MOBILE NUMBER:<br><br>
	Order ID:<br><br>
	
	</div>
	 <div class="col-sm-6">
	<?php echo " <h6>:  ".ucfirst($row1['user_name'])."</h6>" ;  ?>
	<?php echo " <h6>:  ".$row1['user_email']."</h6>" ;  ?>		
	<?php if (empty($row1['MobileNumber'])) { echo "<<h6>--</h6>:"; ?><br><?php  } else {echo " <h6>:  ".$row1['MobileNumber']."</h6>" ;  }?>
	<?php echo ":  ES".rand(100000,999999);?>
    </h6>
	
   </div>
   
  
</div>
						<?php }?>

</div>
<div class="col-sm-2">
</div>
	
<div class="col-sm-12">
			
<section id="cart_items">
		<div class="container">
			
			<div class="review-payment">
				<h2>Your Orders</h2>
			</div>

			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Size</td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
						
						</tr>
					</thead>
					<tbody>  <?php    
                        				  
							$total=0;	   
						include('db.php');  
                        foreach($_SESSION['cartfiles'] as $id=>$value) {						
								  
                            //$cartdata = $conn->query("SELECT * from product where id='$id'");
			                     
                                     //$productimage = $cartdata['ProductImage'];
									 //$productname  = $cartdata['ProductName'];
			                         //$productprice = $cartdata['ProductPrice']; 
									 
		               $stmt = $conn->prepare("SELECT * from product where id='$id'"); 
                       $stmt->execute(); 
                       $row = $stmt->fetch();							 
									 
								    $productimage = $row['ProductImage'];
									$productname  = $row['ProductName'];
			                        $productprice = $row['ProductPrice'];	
                                    

                                     									
									 
									 
									 
									 
									 
									 
									 
                                  ?>
						<tr>
							 <td class="cart_product">
								<a href=""><img src="admin/images/<?php echo $productimage; ?>"  height="110" width="110"alt=""></a>
							</td>
							<td class="cart_description">
								<h4 style="margin-left: 60px;"><a href=""><?php echo $productname ;?></a></h4>
								
							</td>
							<td class="cart_price">
								<input class="cart_quantity_input" type="text" name="size" value="<?php echo $value[1]; ?>" autocomplete="off" size="2" disabled>
							</td>
							<td class="cart_price">
								<p><i class="fa fa-inr" aria-hidden="true"></i>   <?php echo $productprice ;?></p>
							</td>
							
							<td class="cart_quantity">
								<div class="cart_quantity_button">
									
									<input class="cart_quantity_input" type="text" name="quantity" value="<?php echo $value[0]; ?>" autocomplete="off" size="2" disabled>
									
								</div>
							</td>
							<td class="cart_total">
								<p class="cart_total_price"><i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $grandtotal = $productprice* $value[0] ;?></p>
							</td>
							
						</tr>
					<?php 	$total=$total+$grandtotal;?>
						<?php  }  ?>

						
						
					</tbody>
				</table>
			
			</div>
			
		</div>
	
	</section> <!--/#cart_items-->

</div>


    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>